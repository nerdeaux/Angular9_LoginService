// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyBjLJbE0gJ6kCsCKv2Ph2UNpLKzbsWUoTA",
    authDomain: "my12thprojectcrud.firebaseapp.com",
    databaseURL: "https://my12thprojectcrud.firebaseio.com",
    projectId: "my12thprojectcrud",
    storageBucket: "my12thprojectcrud.appspot.com",
    messagingSenderId: "21276878860",
    appId: "1:21276878860:web:e680054fdba70f9a3f2629",
    measurementId: "G-PMTH1PL90K"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
